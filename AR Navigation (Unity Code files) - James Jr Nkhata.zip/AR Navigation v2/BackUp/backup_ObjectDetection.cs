﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.iOS;


public class ObjectDetection : MonoBehaviour
{
    //[SerializeField]
    public Text distanceReading;
    public static float detectedDistance = 0;
    //public Vector2 touchPosition;
   // bool TryGetTouchPosition(out Vector2 touchPosition)
   // {
      //  if (Input.touchCount > 0)
       // {
         //   touchPosition = Input.GetTouch(0).position;
          //  return true;
       // }

//        touchPosition = default;
  //      return false;
  //  }


    // Update is called once per frame
    void Update()
    {
        //List<ARHitTestResult> obstacleHit;
        RaycastHit obstacleHit;
        var ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
        //if (!TryGetTouchPosition(out Vector2 touchPosition))
          //  return;

        if (Physics.Raycast(ray, out obstacleHit))
        {

            detectedDistance = (Mathf.Round(obstacleHit.distance * 100)) / 100;
            distanceReading.text = detectedDistance.ToString();
        }

    }
}



