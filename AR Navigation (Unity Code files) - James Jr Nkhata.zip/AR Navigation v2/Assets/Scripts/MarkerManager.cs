﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.XR.iOS;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using UnityEngine.UI;

namespace MapSaveAndLoadManager
{

    // Classes to hold model information

    [System.Serializable]
    public class ModelInfo
    {
        public float px; //position.x
        public float py; //position.y 
        public float pz; //position.z
        public float qx; //rotation.x 
        public float qy; //rotation.y 
        public float qz; //rotation.z 
        public float qw; //rotation.w
        public bool visited; // flag for visited status
    }

    [System.Serializable]
    public class ModelList
    {
        public ModelInfo[] models;
    }

     // Main Class for Managing Models
    public class MarkerManager : MonoBehaviour
    {

        public GameObject modelPrefab; // 1 prefab ("marker") attached in the inspector

        public static List<ModelInfo> ModelInfoList = new List<ModelInfo>();
        public static List<GameObject> ModelObjList = new List<GameObject>();
        

        // UI Debugging and Testing GameObjects         
        public Text objDistanceReading;        
        public Text tagReading;        
        public float objDistance = 0;

        public static bool isMarkerFlag = false; // Flag used to toggle between detecting a marker for adding and removing 
        public RaycastHit objectHit; // a public variable used to hold Physics Raycast (Unity world space) returned data 

        // Handle for enum AppState in TouchManager
        private TouchManager _appState;

        Vector3 cameraPos; // User postion Vector3 (x, y and z)
        float distanceRadius = 1f; // start the distance radius to search for markers at 1 meter
        float maxDistanceRadius = 5f; // maximum distance radius set to 5 meters

        float distanceCameraToMarker = 0f; // set variable used to hold result between object to camera distance "distanceCameraToMarker" variable to 0. 


        void Start()
        {
            _appState = GetComponent<TouchManager>(); // assign the handle to the TouchManager component            
        }


        void Update()
        {
            MarkerDirectionFinder(); // run the MarkerDirectionFinder() function on every update
            UserPosition(); // run the Update UserPosition() function on every update 
        }

        //Function used to retrieve the position coordinates of the user in the world space
        void UserPosition()
        {
            cameraPos = Camera.main.transform.position; // current position of the camera
        }

        // Function used to check for a gameObject marker (destinationMarker) in the scene
            public void MarkerDirectionFinder()
        {      
            var screenCenter = Camera.main.ViewportPointToRay(new Vector3(0.5f, 0.5f));

            if (Physics.Raycast(screenCenter, out objectHit, maxDistanceRadius*2))
            {

                if (objectHit.transform.tag == "destinationMarker") // marker tag is set to the "marker" prefab through the inspector of Unity
                {
                    // vibrate the iPhone if a destination marker is hit by the physics raycast
                    Handheld.Vibrate();

                    // ipad DOESNT VIBRATE so if a destination marker is hit by the physics raycast play sound too.
                    GetComponent<AudioManager>().MarkerDetectionAlarm();

                    isMarkerFlag = true; // set markerFlag to true to indicate a marker has been hit by the raycast

                    objDistance = (Mathf.Round(objectHit.distance * 100)) / 100;  // set the objDistance from objectHit.distance and round it to two decimal places
                    objDistanceReading.text = "Object Dist: " + objDistance.ToString(); // display on screen for Debugging and testing 
                }
                
            }
            else
            {
                objDistanceReading.text = " "; // clear display on screen for Debugging and testing 
                //tagReading.text = " ";
                isMarkerFlag = false; // set isMarkerFlag to false when it is not hit by the raycast
            }
        }

        // The HitTest to Add a Marker
        public void AddMarker()
        {           
 
                Debug.Log("Not touching a UI button. Moving on.");

            // add marker object 
            float width = Screen.width / 2; // calculate the midpoint of the screen's resolution width (x coordinates)
            float height = Screen.height / 2; // calculate the midpoint of the screen's resolution height (y coordinates)

            // run ScreenToViewportPoint() function on main camera using the center of the mobile device's width and height as its parameters
            var screenPosition = Camera.main.ScreenToViewportPoint(new Vector2(width, height));
            ARPoint point = new ARPoint
                {                     
                    x = screenPosition.x,
                    y = screenPosition.y
                };

                // Place Object Markers on Horizontal planes (floor placement) or FeaturePoints 
                // prioritize results types
                ARHitTestResultType[] resultTypes = {
                        //ARHitTestResultType.ARHitTestResultTypeExistingPlaneUsingExtent,
                        //ARHitTestResultType.ARHitTestResultTypeExistingPlane,
                        ARHitTestResultType.ARHitTestResultTypeEstimatedHorizontalPlane,

                        //ARHitTestResultType.ARHitTestResultTypeEstimatedVerticalPlane,
                        ARHitTestResultType.ARHitTestResultTypeFeaturePoint
                    };

                foreach (ARHitTestResultType resultType in resultTypes)
                {
                    if (AddMarkerHitTestWithResultType(point, resultType))
                    {
                        Debug.Log("Found a hit test result");
                        return;
                    }
                }
            
        }

        // Boolean function used to carryout a ARKit hitTest and convert the Pose to Unity and Placenote's frame of reference
        bool AddMarkerHitTestWithResultType(ARPoint point, ARHitTestResultType resultTypes)
        {
            // Perform a HitTest on the parameters of the specified screen position (point) and ARHitTestResultType (resultTypes)
            List<ARHitTestResult> hitResults = UnityARSessionNativeInterface.GetARSessionNativeInterface().HitTest(point, resultTypes); // Save the HitTest result in an ARHitTestResult List hitResults 

            if (hitResults.Count > 0)
            {
                foreach (var hitResult in hitResults)
                {

                    Debug.Log("Got hit!");

                    //Transform from ARKit frame of reference to Unity World frame of reference (ARKit uses right hand coordinates and Unity uses left hand coordinates) 
                    Vector3 position = UnityARMatrixOps.GetPosition(hitResult.worldTransform); // HitTest results worldTransform postion coordinates
                    Quaternion rotation = UnityARMatrixOps.GetRotation(hitResult.worldTransform); // HitTest results worldTransform rotation coordinates

                    //Transform to placenote frame of reference (planes are detected in ARKit frame of reference)
                    Matrix4x4 worldTransform = Matrix4x4.TRS(position, rotation, Vector3.one); // create a translation, rotation and scale matrix (4 x 4 Matrix) using the converted unity world coordinates and Vector3(1, 1, 1)
                    Matrix4x4? placenoteTransform = LibPlacenote.Instance.ProcessPose(worldTransform); // Return a transform in the current ARKit frame transformed into the inertial frame w.r.t the current Placenote Map

                    Vector3 hitPosition = PNUtility.MatrixOps.GetPosition(placenoteTransform.Value); // Get Position coordinates from the ARKit frame coordinates
                    Quaternion hitRotation = PNUtility.MatrixOps.GetRotation(placenoteTransform.Value);  // Get Rotation coordinates from the ARKit frame coordinates

                    // create model info object
                    ModelInfo modelInfo = new ModelInfo();
                    modelInfo.px = hitPosition.x;
                    modelInfo.py = hitPosition.y;
                    modelInfo.pz = hitPosition.z;
                    modelInfo.qx = hitRotation.x;
                    modelInfo.qy = hitRotation.y;
                    modelInfo.qz = hitRotation.z;
                    modelInfo.qw = hitRotation.w;
                    modelInfo.visited = false; // set the visited object boolean to false
                   
                    AddModel(modelInfo);

                    return true;
                }
            }
            return false;
        }

        // Function used to remove marker GameObject hit by a raycast 
        public void RemoveMarker()
        {
            if (objectHit.collider != null)
            {
                if (ModelObjList != null)
                {
                    foreach (var obj in ModelObjList)
                    {
                        if (obj.name == objectHit.collider.gameObject.GetInstanceID().ToString())
                        {
                            var indexValue = ModelObjList.IndexOf(obj);
                            ModelObjList.Remove(obj);
                            Destroy(objectHit.collider.gameObject);
                            if(ModelInfoList != null)
                            {
                                ModelInfoList.RemoveAt(indexValue);
                            }
                        }
                    }
                }
            }
        }

        
        // Function used to initialise the InitNavigation used to control marker activation and deactivation instantiated in the map 
        public void InitNavigation()
        {
            
            if (ModelInfoList != null)
            {
                StartCoroutine("HideAllModels"); // run coroutine (IEnumerator HideAllModels) 
            } 
        }

        // Function used to start ShowAllModels Coroutine
        public void ShowModelsMapExtend()
        {
            StartCoroutine("ShowAllModels");
        }

        // coroutine used to  hide all the marker GameObjects within the environment
        IEnumerator HideAllModels()
        {
            distanceRadius = 1f; // start the distance at 1 meter
            foreach (GameObject item in ModelObjList)
            {
                item.SetActive(false); // deactivate all the loaded marker gameObjects
            }            
            yield return new WaitForSeconds(0.5f);

            StartCoroutine("RadiusActivatior"); // run coroutine (IEnumerator RadiusActivatior)
        }

        // coroutine used to show all the marker GameObjects hidden within the environment
        IEnumerator ShowAllModels()
        {
            
            foreach (GameObject item in ModelObjList)
            {
                item.SetActive(true); // activate all the loaded marker gameObjects
            }            
            yield return new WaitForSeconds(0.5f);
            
        }

        // coroutine used to handle marker GameObject Occlusion and navigation session Visted markers
        // Adapted from: "https://www.youtube.com/watch?v=kvI2NmlkRUo" Unity Tutorial - Deactivate objects when far from player. 
        IEnumerator RadiusActivatior()
        {

            tagReading.text = ModelInfoList.Count.ToString();
            int markersInRadiusCount = 0;
            for(int x = 0; x < ModelInfoList.Count ; x++) 
            {
                // float 
                distanceCameraToMarker = Vector3.Distance(cameraPos, ModelObjList[x].transform.position);
                tagReading.text = "diff: " + distanceCameraToMarker.ToString() + " visited " + ModelInfoList[x].visited;
                yield return new WaitForSeconds(2f);
                // check if any marker gameObjects are within the current distanceRadius of the camera
                if (distanceCameraToMarker < distanceRadius)
                {
                    // check if the current marker gameObject's ModelInfoList visited flag is false (I.e. that user has not navigated through it yet) 
                    if (ModelInfoList[x].visited == false)
                    {
                        ModelObjList[x].SetActive(true); // activate the current marker
                        markersInRadiusCount++; // increment markersInRadiusCount whenever a marker is within distanceRadius and ModelInfoList[x].visited is false (if true it does not count)    
                    }
                    
                }
                // if previously in range marker gameObjects are out of range of the distanceRadius
                else
                {
                    // check if the current marker gameObject's ModelInfoList visited flag is false (I.e. that user has not navigated through it yet) 
                    if (ModelInfoList[x].visited == false)
                    {
                        ModelObjList[x].SetActive(false); // deactivate the current marker as it is far away to be used
                    }
                }

                // if the distance between the current gameObject marker and the user (CameraPos) is less than or equal to 60 cm
                if (distanceCameraToMarker <= 0.60f)
                {
                    ModelObjList[x].SetActive(false); // Deactivate the gameObject if its within 20 cm of the camera's position 
                    ModelInfoList[x].visited = true; // Set visited flag to true
                }
                                
            }
            // check if no gameObject markers in ModelInfoList and ModelObjList where detected in the current distanceRadius 
            if (markersInRadiusCount == 0)
            {
                // if distanceRadius is less than maxDistanceRadius                
                if (distanceRadius < maxDistanceRadius)
                {
                    distanceRadius += 1f; // extend the range by 1 meter
                }
                // if distance radius is equal to maxDistanceRadius
                else if (distanceRadius == maxDistanceRadius)
                {
                    // reset distance radius to 1 meter
                    distanceRadius = 1f;
                }
            }
            tagReading.text = "Distance Radius " + distanceRadius.ToString();

            yield return new WaitForSeconds(0.5f);
            
            // condition to check if the currentState is still in "Navigate" 
            if (_appState.currentState == TouchManager.AppState.Navigate)
            {
                StartCoroutine("RadiusActivatior"); // re-run coroutine (IEnumerator RadiusActivation)
            }
            
        }        

        // ADDING, DESTROYING AND JSON CONVERSION OF MARKER MODELS
        #region Create, Delete convert and Models with JSON
        // Function used to instantiate gameObjects from modelInfo as well add the information and object to the "ModelInfoList" and "ModelObjList" 
        public void AddModel(ModelInfo modelInfo)
        {

            GameObject newModel = Instantiate(modelPrefab); // instantiate from [System.Serializable] prefab 

            newModel.transform.position = new Vector3(modelInfo.px, modelInfo.py, modelInfo.pz); // set the position of the newModel object
            newModel.transform.rotation = new Quaternion(modelInfo.qx, modelInfo.qy, modelInfo.qz, modelInfo.qw); // set the rotation of the newModel object

            newModel.name = newModel.GetInstanceID().ToString(); // use the GetInstance() to add the unique object identifier as name property for ModelObjList important to add and remove markers without looping through            

            ModelObjList.Add(newModel); // add current model to ModelObjList            
            ModelInfoList.Add(modelInfo); // add current modelInfo to ModelInfoList
        }

        public void ClearModels()
        {
            foreach (var obj in ModelObjList)
            {
                Destroy(obj);
            }
            ModelObjList.Clear();
            ModelInfoList.Clear();
        }

        // Function used to destroy all the GameObjects in the scene that have the passed string tag name
        public void DestroyMarkers(string tag)
        {
            GameObject[] markergameObjects = GameObject.FindGameObjectsWithTag(tag); 
            if(markergameObjects != null)
            {
                foreach (GameObject marker in markergameObjects)
                {
                    GameObject.Destroy(marker);
                }
            }
        }


        // Helper Functions to convert (Serialize and Deserialize) models to and from JSON objects
        // Create JSON file from "ModelInfoList"
        public JObject Models2JSON()
        {
            ModelList modelList = new ModelList();
            modelList.models = new ModelInfo[ModelInfoList.Count];
            for (int i = 0; i < ModelInfoList.Count; i++)
            {
                modelList.models[i] = ModelInfoList[i];
            }

            return JObject.FromObject(modelList);
        }

        // Load and deserialize GameObjects from mapMetadata
        public void LoadModelsFromJSON(JToken mapMetadata)
        {
            ClearModels();

            if (mapMetadata is JObject && mapMetadata["modelList"] is JObject)
            {
                ModelList modelList = mapMetadata["modelList"].ToObject<ModelList>();
                if (modelList.models == null)
                {
                    Debug.Log("no models added");
                    return;
                }

                // foreach loop used to load models from JSON back to "ModelObjList" and the scene as GameObjects
                foreach (var modelInfo in modelList.models)
                {
                    AddModel(modelInfo); 
                }
            }

        }
    #endregion
    }

}

