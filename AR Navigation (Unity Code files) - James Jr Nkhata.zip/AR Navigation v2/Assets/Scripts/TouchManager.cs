﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.XR.iOS;
using UnityEngine.UI;

namespace MapSaveAndLoadManager
{

    public class TouchManager : MonoBehaviour
    {
        // Create enum for the different states of the app
        public enum AppState
        {
            Home,
            MapLoad,
            MapCreate,
            Navigate,
            MapExtend
        }

        public AppState currentState; // create a variable "currentState" for the app states 

        // Create enum for the different states between ARHitTestResultType Result Types for "DistanceDetectionManager.cs" Physical Distance
        public enum ARHitTestResultTypeChoice
        {
            AllResultTypes = 0,
            ExistingPlaneUsingExtent = 1,
            ExistingPlaneUsingGeometry = 2,
            ExistingPlane = 3,
            EstimatedHorizontalPlane = 4,
            EstimatedVerticalPlane = 5,
            FeaturePoint = 6
        }

        public ARHitTestResultTypeChoice desiredResultType = 0; // create a variable "desiredResultType" for the HitTestResultTypeChoice

        // Touch and Swipe 
        public float maxTime = 1f; // 1 second
        public float minSwipeDist = 100; // 100 pixels
        public bool screenSwiped = false;

        float swipeDistance;
        float touchTime;

        float startTime;
        float endTime;

        Vector3 startPos;
        Vector3 endPos;

        public Text displayAppState;
        public Text displayHitTestResultTypeChoice;


        void Update()
        {
            DisplaySystemState(); // Run the DisplaySystemState() function
            
            
            // Check if the screen is touched

            // ONE FINGER TOUCH COMMANDS
            #region ONE FINGER TOUCH
            // check if only one finger is detected on the screen
            if (Input.touchCount == 1)
            {
                Touch touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Moved)
                {
                    screenSwiped = true;
                }
                if (touch.phase == TouchPhase.Began)
                {
                    startTime = Time.time;
                    startPos = touch.position;
                    
                }
                else if (touch.phase == TouchPhase.Ended)
                {
                    endTime = Time.time;
                    endPos = touch.position;

                    swipeDistance = (endPos - startPos).magnitude;
                    touchTime = endTime - startTime;

                    if (touchTime < maxTime && swipeDistance > minSwipeDist && screenSwiped == true)
                    {
                        Swipe();
                        screenSwiped = false;
                    }
                    else if (touchTime > 0 && touchTime < 2 && screenSwiped == false)
                    {
                           GetComponent<DistanceDetectionManager>().DistanceFinder();                        
                    }

                    else
                    {
                        screenSwiped = false;
                    }

                }
                // Screen held down with one touch 
                else if (touch.phase == TouchPhase.Stationary)
                {
                    if ((Time.time - startTime) > 2)
                    {
                        GetComponent<DistanceDetectionManager>().DistanceFinder();
                    }

                }
            }
            #endregion

            // TWO FINGER TOUCH COMMANDS
            #region TWO FINGER TOUCH 
            // two finger touch on the phone/tablet screen should place a marker on the EstimatedHorizontalPlane
            else if (Input.touchCount == 2)
            {
                Touch touch0 = Input.GetTouch(0);
                Touch touch1 = Input.GetTouch(1);
                if (touch0.phase == TouchPhase.Began && touch1.phase == TouchPhase.Began)
                {
                    startTime = Time.time;
                }
                else if (touch0.phase == TouchPhase.Ended || touch1.phase == TouchPhase.Ended)
                {
                    endTime = Time.time;
                    touchTime = endTime - startTime;

                    // check if the touchTime is greater than 0 , less than 2 seconds and currentState is on AppState.MapCreate or AppState.MapExtend
                    if (((touchTime > 0 && touchTime < 2) && (currentState == AppState.MapCreate || currentState == AppState.MapExtend)))
                    {
                        // Add a marker to a HitTest Result if isMarkerFlag is false
                        if (MarkerManager.isMarkerFlag == false)
                        {
                            GetComponent<MarkerManager>().AddMarker();
                        }
                        // Destroy a HitTest Result detected marker if isMarkerFlag is set to true
                        if (MarkerManager.isMarkerFlag == true)
                        {
                            GetComponent<MarkerManager>().RemoveMarker();
                        }
                    }

                    // check if the two finger touchTime is greater than 2 seconds
                    if (touchTime > 2)
                    {
                        GetComponent<AudioManager>().AppStateHelpNotifications(); // run AppStateHelpNotification() function

                    }

                }
 
            }
            #endregion
            // THREE FINGER TOUCH COMMANDS
            #region THREE FINGER TOUCH 
            // three finger touch on the phone/tablet screen should Save the map
            else if (Input.touchCount == 3)
            {
                Touch touch0 = Input.GetTouch(0);
                Touch touch1 = Input.GetTouch(1);
                Touch touch2 = Input.GetTouch(2);
                if (touch0.phase == TouchPhase.Began && touch1.phase == TouchPhase.Began && touch2.phase == TouchPhase.Began)
                {
                    startTime = Time.time;
                }
                else if (touch0.phase == TouchPhase.Ended || touch1.phase == TouchPhase.Ended || touch2.phase == TouchPhase.Ended)
                {
                    endTime = Time.time;
                    touchTime = endTime - startTime;

                    // check if the touchTime is less than the maxTime
                    if (touchTime > 0 && touchTime < 2)
                    {
                        // Run SwitchDesiredResultType() function used to toggle between "DistanceDetectionManager.cs" HitTestResultTypeChoice for Physical Distance ARHitTestResultType Result Types:
                        // AllResultTypes = 0, ExistingPlaneUsingExtent = 1, ExistingPlane = 2, EstimatedHorizontalPlane = 3, EstimatedVerticalPlane = 4, FeaturePoint = 5

                        SwitchDesiredResultType();

                    }

                }

            }
            #endregion    
        }

        private void Swipe()
        {
            Vector2 touchDistance = endPos - startPos;

            // Horizontal Swipe 
            if (Mathf.Abs(touchDistance.x) > Mathf.Abs(touchDistance.y))
            {

                // Right Swipe to create a new map (if the currentState is AppState.Home Only)
                if (touchDistance.x > 0 && currentState == AppState.Home)
                {                    
                    GetComponent<MapSaveAndLoadManager>().OnNewMapClick(); // run the OnNewMapClick() function
                    if (MarkerManager.ModelInfoList != null && MarkerManager.ModelObjList != null)
                    {
                        GetComponent<MarkerManager>().ClearModels();
                    }

                }
                // Right Swipe to extend the current map (if the currentState is AppState.Navigate)
                if (touchDistance.x > 0 && currentState == AppState.Navigate)
                {
                    // START UP CREATE MAPPING WITHOUT THE MODEL CLEARING
                    GetComponent<MapSaveAndLoadManager>().OnExtendMapClick(); // run the OnExtendMapClick() function
                    if (MarkerManager.ModelInfoList != null && MarkerManager.ModelObjList != null)
                    {
                        // REACTIVATE ALL MODELS WITHIN THE SCENE
                        GetComponent<MarkerManager>().ShowModelsMapExtend();
                    }

                }
                // Left Swipe (if the currentState is Not AppState.Home)
                if (touchDistance.x < 0 && currentState != AppState.Home)
                {                    
                     GetComponent<MapSaveAndLoadManager>().OnExitClick(); // swipe left to exit from current task
                }
            }

            // Vertical Swipe
            else if (Mathf.Abs(touchDistance.x) < Mathf.Abs(touchDistance.y))
            {

                // Up Swipe (if the currentState is AppState.MapCreate or AppState.MapExtend)
                if (touchDistance.y > 0 &&(currentState == AppState.MapCreate || currentState == AppState.MapExtend))
                {                    
                    GetComponent<MapSaveAndLoadManager>().OnSaveMapClick(); // swipe up to save map
                }
                // Down Swipe (if the currentState is AppState.Home or AppState.Navigate to prevent the user from accidentally load map during map creation or map extending )
                if (touchDistance.y < 0 && (currentState == AppState.Home || currentState == AppState.Navigate))
                {                 
                    GetComponent<MapSaveAndLoadManager>().OnLoadMapClicked(); // swipe down to load map                    
                }
            }
        }
        // Function used to toggle between HitTestResultTypeChoice Options 
        public void SwitchDesiredResultType()
        {
            switch (desiredResultType)
            {
                case ARHitTestResultTypeChoice.AllResultTypes:
                    desiredResultType = ARHitTestResultTypeChoice.EstimatedHorizontalPlane;
                    break;
                case ARHitTestResultTypeChoice.EstimatedHorizontalPlane:
                    desiredResultType = ARHitTestResultTypeChoice.EstimatedVerticalPlane;
                    break;
                case ARHitTestResultTypeChoice.EstimatedVerticalPlane:
                    desiredResultType = ARHitTestResultTypeChoice.ExistingPlane;
                    break;
                case ARHitTestResultTypeChoice.ExistingPlane:
                    desiredResultType = ARHitTestResultTypeChoice.ExistingPlaneUsingExtent;
                    break;

                case ARHitTestResultTypeChoice.ExistingPlaneUsingExtent:
                    desiredResultType = ARHitTestResultTypeChoice.ExistingPlaneUsingGeometry;
                    break;

                case ARHitTestResultTypeChoice.ExistingPlaneUsingGeometry:
                    desiredResultType = ARHitTestResultTypeChoice.FeaturePoint;
                    break;
                case ARHitTestResultTypeChoice.FeaturePoint:
                    desiredResultType = ARHitTestResultTypeChoice.AllResultTypes;
                    break;
                default:
                    desiredResultType = ARHitTestResultTypeChoice.AllResultTypes;
                    break;
            }
        }
        public void DisplaySystemState()
        {
            // Condtional statements to display AppState
            if (currentState == AppState.Home)
            {
                displayAppState.text = "Mode: " + "Home";
            }
            else if (currentState == AppState.MapCreate)
            {
                displayAppState.text = "Mode: " + "Map Creation";
            }
            else if (currentState == AppState.Navigate)
            {
                displayAppState.text = "Mode: " + "Navigation";
            }
            else if (currentState == AppState.MapExtend)
            {
                displayAppState.text = "Mode: " + "Extending Map";
            }

            // Condtional statements to display selected HitTestResultTypeChoice
            if (desiredResultType == ARHitTestResultTypeChoice.AllResultTypes)
            {
                displayHitTestResultTypeChoice.text = "AllResultTypes";
            }
            else if (desiredResultType == ARHitTestResultTypeChoice.EstimatedHorizontalPlane)
            {
                displayHitTestResultTypeChoice.text = "EstimatedHorizontalPlane";
            }
            else if (desiredResultType == ARHitTestResultTypeChoice.EstimatedVerticalPlane)
            {
                displayHitTestResultTypeChoice.text = "EstimatedVerticalPlane";
            }
            else if (desiredResultType == ARHitTestResultTypeChoice.ExistingPlane)
            {
                displayHitTestResultTypeChoice.text = "ExistingPlane";
            }
            else if (desiredResultType == ARHitTestResultTypeChoice.ExistingPlaneUsingExtent)
            {
                displayHitTestResultTypeChoice.text = "ExistingPlaneUsingExtent";
            }

            else if (desiredResultType == ARHitTestResultTypeChoice.ExistingPlaneUsingGeometry)
            {
                displayHitTestResultTypeChoice.text = "ExistingPlaneUsingGeometry";
            }

            else if (desiredResultType == ARHitTestResultTypeChoice.FeaturePoint)
            {
                displayHitTestResultTypeChoice.text = "FeaturePoint";
            }

        }

    }
    
}