﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;
using UnityEngine.XR.iOS;
using System.Runtime.InteropServices;
using System.IO;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace MapSaveAndLoadManager
{
    public class MapSaveAndLoadManager : MonoBehaviour, PlacenoteListener
    {

        [SerializeField] Text mLabelText; // display on screen for Debugging and testing
        [SerializeField] PlacenoteARGeneratePlane mPlaneGenerator; // used to visual planes for debugging and testing


        // Unity ARKit Session handler
        private UnityARSessionNativeInterface mSession;

        // Handle for enum AppState in TouchManager
        private TouchManager _appState;

        private LibPlacenote.MapInfo mCurrMapInfo;   // variable used for current map info
                
        private string mCurrMapId; // string used to hold the last saved MapID
        private LibPlacenote.MapMetadata downloadedMetaData; // variable used for map metadata info


        private bool mARKitInit = false; // Boolean for Intializing ARKit
        private bool localizedFirstTime = false; // Boolean used to manipulate map loading behaviour

        // Use this for initialization
        void Start()
        {
            _appState = GetComponent<TouchManager>(); // assign the handle to the TouchManager component
            
            _appState.currentState = TouchManager.AppState.Home; // change state to AppState.Home         
            
            downloadedMetaData = new LibPlacenote.MapMetadata(); // assign a varaible for the MapMetadata
            Input.location.Start(); // property for accessing mobile device GPS location information
           
            // assign an Session instance for ARKit
            mSession = UnityARSessionNativeInterface.GetARSessionNativeInterface();
            StartARKit(); // Start ARKit using the Unity ARKit Plugin
            FeaturesVisualizer.EnablePointcloud();
            LibPlacenote.Instance.RegisterListener(this);

            // start to generate and display planes with PlacenoteARGeneratePlane's StartPlaneDetection()
            mPlaneGenerator.StartPlaneDetection();
            // check if LibPlacnote has been initialized
            if (LibPlacenote.Instance.Initialized())
            {

                GetComponent<AudioManager>().PlayAfterDelay(AudioManager.initializedAudio, 1f);
            }

        }

        // Function used to Exit the current state the application is in.
        public void OnExitClick()
        {
            if (_appState.currentState != TouchManager.AppState.MapExtend)
            {
                LibPlacenote.Instance.StopSession(); // Stop Session
            //    if(_appState.currentState != TouchManager.AppState.MapLoad)
            //    {
                    AudioManager.audioSource.PlayOneShot(AudioManager.exitAudio); // PLAY exit notification sound
            //    }
                _appState.currentState = TouchManager.AppState.Home; // change state to AppState.Home
                

                GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function
                                
                FeaturesVisualizer.DisablePointcloud(); // Disable FeaturesVisualizer
                FeaturesVisualizer.clearPointcloud(); // Clear PointCloud Data
                GetComponent<MarkerManager>().ClearModels(); // Clear ModelInfoList and ModelObjList on Exit (OnExitClick)
                GetComponent<MarkerManager>().DestroyMarkers("destinationMarker"); // Clear all Marker GameObjects in the scene that have the string tag "destinationMarker"

                ConfigureSession(true, true); // continue plane detection and delete existing planes                              
                
            }
            else if (_appState.currentState == TouchManager.AppState.MapExtend)
            {
                _appState.currentState = TouchManager.AppState.Navigate; // change state to AppState.Navigate
                GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function

                GetComponent<MarkerManager>().InitNavigation(); // INTIALIZE MARKER ACTIVATOR OCCLUSION COROUTINE AND FUNCTIONS                            

                LibPlacenote.Instance.StartSession();
                FeaturesVisualizer.EnablePointcloud(); // re-enable pointcloud Feature Visualizer
                                
                ConfigureSession(true, false); // Start Plane Detection, dont delete existing planes

            }
        }


        // Load map and relocalize. Check OnStatusChange function for behaviour upon relocalization
        public void OnLoadMapClicked()
        {
            _appState.currentState = TouchManager.AppState.MapLoad; // change state to AppState.MapLoad
            GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function
            
            LibPlacenote.Instance.StopSession();
            ConfigureSession(false, true); // Stop Plane Detection, delete existing planes
            FeaturesVisualizer.DisablePointcloud(); // disable FeaturesVisualizer
  
            if (!LibPlacenote.Instance.Initialized())
            {
                mLabelText.text = "SDK not yet initialized";
                return;
            }

            // Reading the last saved MapID from file
            mCurrMapId = LoadMapIDFromFile();

            LibPlacenote.Instance.LoadMap(mCurrMapId,
            (completed, faulted, percentage) =>
            {
                if (completed)
                {
                    // Get the meta data as soon as the map is downloaded
                    LibPlacenote.Instance.GetMetadata(mCurrMapId, (LibPlacenote.MapMetadata obj) =>
                    {
                        if (obj != null)
                        {
                            downloadedMetaData = obj;

                            FeaturesVisualizer.clearPointcloud(); //  clear PointCloud Data

                            // Now trying to localize the map
                            mLabelText.text = "Trying to Localize Map: " + mCurrMapId;
                            AudioManager.audioSource.PlayOneShot(AudioManager.searchingAreaAudio); // PLAY searchingAreaAudio for trying to localize notification sound
                            LibPlacenote.Instance.StartSession(); // Start the session
                        }
                        else
                        {
                            mLabelText.text = "Failed to download meta data";

                            AudioManager.audioSource.PlayOneShot(AudioManager.noMapFoundAudio); // PLAY no map information found notification sound

                            return;
                        }
                    });

                }
                else if (faulted)
                {
                    mLabelText.text = "Failed to load ID: " + mCurrMapId;
                    
                    AudioManager.audioSource.PlayOneShot(AudioManager.loadingFailedAudio); // PLAY loading map failed notification sound
                    
                    // Exit and go to AppState.Home
                    _appState.currentState = TouchManager.AppState.Home;
                    OnExitClick(); // Exit 
                }
                else
                {
                    mLabelText.text = "Download Progress: " + percentage.ToString("F2") + "/1.0)"; // for debugging and testing
                }
            }

            );
        }

        /* COMMENTED OUT MAP DELETING AS THERE IS NO NEED FOR IT CURRENTLY. KEPT FOR FUTURE WORK
        public void OnDeleteMapClicked()
        {
            if (!LibPlacenote.Instance.Initialized())
            {
                Debug.Log("SDK not yet initialized");
                return;
            }

            mLabelText.text = "Deleting Map ID: " + mCurrMapId;
            LibPlacenote.Instance.DeleteMap(mCurrMapId, (deleted, errMsg) =>
            {
                if (deleted)
                {
                    mLabelText.text = "Deleted ID: " + mCurrMapId;
                }
                else
                {
                    mLabelText.text = "Failed to delete ID: " + mCurrMapId;
                }
            });
        }
        */
        
        public void OnNewMapClick()
        {
            if (!LibPlacenote.Instance.Initialized())
            {
                AudioManager.audioSource.PlayOneShot(AudioManager.notIntializedAudio); // PLAY not intialized notification sound
                Debug.Log("SDK not yet initialized");
                return;
            }
            
            _appState.currentState = TouchManager.AppState.MapCreate; // change state to AppState.MapCreate

            GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function
            
            GetComponent<MarkerManager>().ClearModels(); // Clear ModelInfoList and ModelObjList

            // start plane detection
            ConfigureSession(true, true); // Start Plane Detection, delete existing planes

            // start to generate and display planes with PlacenoteARGeneratePlane's StartPlaneDetection()
            mPlaneGenerator.StartPlaneDetection();

            FeaturesVisualizer.EnablePointcloud(); // enable FeaturesVisualizer
            LibPlacenote.Instance.StartSession(); // start session

        }

        // Initialize ARKit.
        private void StartARKit()
        {
            mLabelText.text = "Initializing ARKit"; // for debugging and testing
            Application.targetFrameRate = 60; // set framerate
            ConfigureSession(true, false); // start Start Plane Detection, do not delete existing planes
        }

        // Function used to configure the ARKit session and toggle PlaneDetection and Plane Clearing
        private void ConfigureSession(bool togglePlaneDetection, bool clearOldPlanes)
        {

            ARKitWorldTrackingSessionConfiguration config = new ARKitWorldTrackingSessionConfiguration();

            if (togglePlaneDetection)
            {
                if (UnityARSessionNativeInterface.IsARKit_1_5_Supported())
                {
                    config.planeDetection = UnityARPlaneDetection.HorizontalAndVertical;
                }
                else
                {
                    config.planeDetection = UnityARPlaneDetection.Horizontal;
                }

            }
            else
            {
                config.planeDetection = UnityARPlaneDetection.None;
            }

            if (clearOldPlanes)
            {
                mPlaneGenerator.ClearPlanes();
            }

            config.alignment = UnityARAlignment.UnityARAlignmentGravity;
            config.getPointCloudData = true;
            config.enableLightEstimation = true;
            UnityARSessionRunOption options = new UnityARSessionRunOption();
            /* DESCRIPTION OF THE CONFIG OPTIONS AVAILABLE FOR RESETTING TRACKING AND REMOVING EXISTING ANCHORS 
            ARSessionRunOptionResetTracking - The session does not continue device position/ motion tracking from the previous configuration.            
            ARSessionRunOptionRemoveExistingAnchors - Any anchor objects associated with the session in its previous configuration are removed.*/

            //options = UnityARSessionRunOption.ARSessionRunOptionRemoveExistingAnchors | UnityARSessionRunOption.ARSessionRunOptionResetTracking;
            options = UnityARSessionRunOption.ARSessionRunOptionRemoveExistingAnchors;
            mSession.RunWithConfigAndOptions(config, options);

        }

        public void OnSaveMapClick()
        {
            if (!LibPlacenote.Instance.Initialized())
            {
                AudioManager.audioSource.PlayOneShot(AudioManager.notIntializedAudio); // PLAY not intialized notification sound
                Debug.Log("SDK not yet initialized");

                return;
            }

            bool useLocation = Input.location.status == LocationServiceStatus.Running;
            LocationInfo locationInfo = Input.location.lastData;

            mLabelText.text = "Saving...";
            AudioManager.audioSource.PlayOneShot(AudioManager.savingAudio); // PLAY map saving notification sound
            LibPlacenote.Instance.SaveMap(
                (mapId) =>
                {
                    LibPlacenote.Instance.StopSession();
                    FeaturesVisualizer.DisablePointcloud(); // Disable pointcloud Featture Visualizer
                                                            

                    mLabelText.text = "Saved Map ID: " + mapId;
                    
                    LibPlacenote.MapMetadataSettable metadata = CreateMetaDataObject();

                    LibPlacenote.Instance.SetMetadata(mapId, metadata, (success) =>
                    {
                        if (success)
                        {
                            mLabelText.text = "Meta data successfully saved";
                        }
                        else
                        {
                            mLabelText.text = "Meta data failed to save";
                            AudioManager.audioSource.PlayOneShot(AudioManager.errorAudio); // PLAY error notification sound
                        }
                    });

                    SaveMapIDToFile(mapId);

                },
                (completed, faulted, percentage) =>
                {

                    if (completed)
                    {
                        mLabelText.text = "Upload Complete:";
                        _appState.currentState = TouchManager.AppState.Navigate; // put app in AppState.Navigate for map following
                        GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function
                        FeaturesVisualizer.EnablePointcloud(); // re-enable pointcloud Feature Visualizer                        

                        GetComponent<MarkerManager>().InitNavigation(); // INTIALIZE MARKER ACTIVATOR OCCLUSION COROUTINE AND FUNCTIONS

                        ConfigureSession(true, false); // Start Plane Detection, dont delete existing planes

                    }
                    else if (faulted)
                    {
                        mLabelText.text = "Upload of Map failed";
                        AudioManager.audioSource.PlayOneShot(AudioManager.savingFailedAudio); // PLAY saving failed notification sound
                    }
                    else
                    {
                        mLabelText.text = "Upload Progress: " + percentage.ToString("F2") + "/1.0)";
                        
                    }

                }
            );
        }


        public void OnExtendMapClick()
        {
            LibPlacenote.Instance.StartSession(true); // true flag is used to  extend a previously created map, after a successful localization
            _appState.currentState = TouchManager.AppState.MapExtend; // set to AppState.MapExtend
            GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function
            
        }


        // Function used to create Map MetaData that contains GameObject and location data
        public LibPlacenote.MapMetadataSettable CreateMetaDataObject()
        {
            LibPlacenote.MapMetadataSettable metadata = new LibPlacenote.MapMetadataSettable();

            metadata.name = "AR Nav Map";

            // get GPS location of device to save with map
            bool useLocation = Input.location.status == LocationServiceStatus.Running;
            LocationInfo locationInfo = Input.location.lastData;
            if (useLocation)
            {
                metadata.location = new LibPlacenote.MapLocation();
                metadata.location.latitude = locationInfo.latitude;
                metadata.location.longitude = locationInfo.longitude;
                metadata.location.altitude = locationInfo.altitude;
            }

            JObject userdata = new JObject(); // create JObject varaible

            // Get JSON Model data created from MarkerManager.cs
            JObject modelList = GetComponent<MarkerManager>().Models2JSON();
            userdata["modelList"] = modelList; // add to an entry field in the userdata referenced by the "modelist" string

            
            metadata.userdata = userdata; // assign userdata to metadata.userdata 
            return metadata;
        }

        // Function used to mapid
        public void SaveMapIDToFile(string mapid)
        {
            string filePath = Application.persistentDataPath + "/mapIDFile.txt";
            StreamWriter sr = File.CreateText(filePath);
            sr.WriteLine(mapid);
            sr.Close();
        }

        // Function used to load from mapid
        public string LoadMapIDFromFile()
        {
            string savedMapID;
            // read history file
            FileInfo historyFile = new FileInfo(Application.persistentDataPath + "/mapIDFile.txt");
            StreamReader sr = historyFile.OpenText();
            string text;
            do
            {
                text = sr.ReadLine();
                if (text != null)
                {
                    // Create drawing command structure from string.
                    savedMapID = text;
                    return savedMapID;

                }
            } while (text != null);
            return null;
        }

        // Callback used to publish the computed poses along with its corresponding ARKit pose to listeners
        public void OnPose(Matrix4x4 outputPose, Matrix4x4 arkitPose) { }

        // Function used to handle status changes 
        public void OnStatusChange(LibPlacenote.MappingStatus prevStatus, LibPlacenote.MappingStatus currStatus)
        {
            Debug.Log("prevStatus: " + prevStatus.ToString() + " currStatus: " + currStatus.ToString());
            if (currStatus == LibPlacenote.MappingStatus.RUNNING && prevStatus == LibPlacenote.MappingStatus.LOST)
            {
                
                // Placenote has successfully localized your map

                mLabelText.text = "Localized State!";

                if (!localizedFirstTime)
                {
                    //localizedFirstTime = true;

                    mLabelText.text = "Localized: loaded shapes";

                    JToken modelData = downloadedMetaData.userdata; // retrieve metadata
                    GetComponent<MarkerManager>().LoadModelsFromJSON(modelData); // load models from the JSON

                    _appState.currentState = TouchManager.AppState.Navigate; // put app in AppState.Navigate for map following
                    GetComponent<AudioManager>().AppStateNotification(); // run Audio Manager AppStateNotification() function

                    ConfigureSession(true, false); // Start Plane Detection, dont delete existing planes
                    FeaturesVisualizer.EnablePointcloud(); // enable FeatureVisualizer

                    GetComponent<MarkerManager>().InitNavigation(); // INTIALIZE MARKER ACTIVATOR OCCLUSION COROUTINE AND FUNCTIONS

                    // stops the Placenote loading session
                    LibPlacenote.Instance.StopSession();

                }
            }
            else if (currStatus == LibPlacenote.MappingStatus.RUNNING && prevStatus == LibPlacenote.MappingStatus.WAITING)
            {
                // Started a new mapping Session

                mLabelText.text = "Mapping";

            }
            else if (currStatus == LibPlacenote.MappingStatus.LOST)
            {
                // Lost map, trying to localize again

                mLabelText.text = "Searching for position lock";
                

            }
            else if (currStatus == LibPlacenote.MappingStatus.WAITING)
            {
                // After stop session is called.
            }
        }
    }
}

