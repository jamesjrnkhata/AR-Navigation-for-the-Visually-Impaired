﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.iOS;

namespace MapSaveAndLoadManager
{
    public class DistanceDetectionManager : MonoBehaviour
    {            

        public Text physDistanceReading; // display on screen for Debugging and testing
        public double physDistance = 0;
                
        public GameObject rayHitIndicator; // GameObject used to indicator a HitTest intersection point
        private Pose rayHitPose; // pose type variable         
        private bool rayHitPoseIsValid = false; // flag used to indicate if a pose detected by a HitTest exists

        // Handle for enum HitTestResultTypeChoice in TouchManager
        private TouchManager _hitTest;
        void Start()
        {
            _hitTest = GetComponent<TouchManager>(); // assign the handle to the TouchManager component
        }

        // Function used to start the first part of finding the distance between the centre coordinates of the phone screen to the physical objects in the real space
        public void DistanceFinder()
            {
            float width = Screen.width / 2; // calculate the midpoint of the screen's resolution width (x coordinates)
            float height = Screen.height / 2; // calculate the midpoint of the screen's resolution height (y coordinates)
            
            // run ScreenToViewportPoint() function on main camera using the center of the mobile device's width and height as its parameters
            var screenPosition = Camera.main.ScreenToViewportPoint(new Vector2(width, height));
            ARPoint point = new ARPoint
            {
                x = screenPosition.x,
                y = screenPosition.y
            };
            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to ExistingPlaneUsingExtent
            if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.ExistingPlaneUsingExtent)
            {
                ARHitTestResultType resultType = ARHitTestResultType.ARHitTestResultTypeExistingPlaneUsingExtent;
                if (DistanceFinderHitTestWithResultType(point, resultType))
                {                 
                    return;
                }
            }

            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to ExistingPlaneUsingGeometry
            else if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.ExistingPlaneUsingGeometry)
            {
                ARHitTestResultType resultType = ARHitTestResultType.ARHitTestResultTypeExistingPlaneUsingGeometry;
                if (DistanceFinderHitTestWithResultType(point, resultType))
                {
                    return;
                }
            }

            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to ExistingPlane
            else if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.ExistingPlane)
            {
                ARHitTestResultType resultType = ARHitTestResultType.ARHitTestResultTypeExistingPlane;
                if (DistanceFinderHitTestWithResultType(point, resultType))
                {
                    return;
                }
            }

            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to EstimatedHorizontalPlane
            else if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.EstimatedHorizontalPlane)
            {
                ARHitTestResultType resultType = ARHitTestResultType.ARHitTestResultTypeEstimatedHorizontalPlane;
                if (DistanceFinderHitTestWithResultType(point, resultType))
                {
                    return;
                }
            }

            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to EstimatedVerticalPlane
            else if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.EstimatedVerticalPlane)
            {
                ARHitTestResultType resultType = ARHitTestResultType.ARHitTestResultTypeEstimatedVerticalPlane;
                if (DistanceFinderHitTestWithResultType(point, resultType))
                {
                    return;
                }
            }

            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to FeaturePoint
            else if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.FeaturePoint)
            {
                ARHitTestResultType resultType = ARHitTestResultType.ARHitTestResultTypeFeaturePoint;
                if (DistanceFinderHitTestWithResultType(point, resultType))
                {
                    return;
                }
            }
            // condition to check if the enumerator ARHitTestResultTypeChoice state is set to AllResultTypes
            else if (_hitTest.desiredResultType == TouchManager.ARHitTestResultTypeChoice.AllResultTypes)
            {
                // prioritize results types 
                ARHitTestResultType[] resultTypes = {
                        ARHitTestResultType.ARHitTestResultTypeExistingPlaneUsingExtent,                        
                        ARHitTestResultType.ARHitTestResultTypeExistingPlaneUsingGeometry,
                        ARHitTestResultType.ARHitTestResultTypeExistingPlane,
                        ARHitTestResultType.ARHitTestResultTypeEstimatedVerticalPlane,
                        ARHitTestResultType.ARHitTestResultTypeEstimatedHorizontalPlane,
                        ARHitTestResultType.ARHitTestResultTypeFeaturePoint
                    };

                foreach (ARHitTestResultType resultType in resultTypes)
                {
                    if (DistanceFinderHitTestWithResultType(point, resultType))
                    {
                        Debug.Log("Found a hit test result");
                        return;
                    }
                }
            }

        }

        // Adapted from: "https://www.youtube.com/watch?v=Ml2UakwRxjk&t=908s" - Getting Started With ARFoundation in Unity (ARKit, ARCore)
        // Function used to complete the  DistanceFinder() functions distance detection 
        bool DistanceFinderHitTestWithResultType(ARPoint point, ARHitTestResultType resultTypes)
        {
            // Perform a HitTest on the parameters of the specified screen position (point) and ARHitTestResultType (resultTypes)
            List<ARHitTestResult> hitResults = UnityARSessionNativeInterface.GetARSessionNativeInterface().HitTest(point, resultTypes); // Save the HitTest result in an ARHitTestResult List hitResults 

            if (hitResults.Count > 0)
            {
                rayHitPoseIsValid = hitResults.Count > 0; // rayHitPoseIsValid if the HitTest has more than 0 hits

                foreach (var hitResult in hitResults)
                {

                    Debug.Log("Got hit!");

                    if (rayHitPoseIsValid)
                    {
                        //Transform from ARKit frame of reference to Unity World frame of reference  
                        rayHitPose.position = UnityARMatrixOps.GetPosition(hitResult.worldTransform); // HitTest results worldTransform postion coordinates
                        rayHitPose.rotation = UnityARMatrixOps.GetRotation(hitResult.worldTransform); // HitTest results worldTransform rotation coordinates

                        // the rayHitIndicator will not turn on device rotation, because the orientation is set to the direction the device was facing when ARKit started up
                        // the following three lines help to fix the rotation issue and make the rayHitIndicator turn as the device turns
                        var cameraForward = Camera.main.transform.forward;
                        var cameraBearing = new Vector3(cameraForward.x, 0, cameraForward.z).normalized;
                        rayHitPose.rotation = Quaternion.LookRotation(cameraBearing);

                        rayHitIndicator.transform.SetPositionAndRotation(rayHitPose.position, rayHitPose.rotation); // function used to simulatenously set the Position and Rotation
                        rayHitIndicator.SetActive(true); // show rayHitIndicator 
                    }
                    else
                    {
                        rayHitIndicator.SetActive(false); // hide rayHitIndicator
                    }
                                        
                    physDistance = (Math.Round(hitResult.distance * 100)) / 100; // set the physDistance from hitResult.distance and round it to two decimal places 
                    physDistanceReading.text = "Phys Dist: " + physDistance.ToString(); // use the physDistanceReading User Interface text object to display the distance

                    // Give an audio indicator for distance readings
                    GetComponent<AudioManager>().ObjectDistanceAlarm(physDistance); // AudioManager function ObjectDistanceAlarm() used to play distance notification sound 

                    return true;
                }
            }
            else
            {
                physDistanceReading.text = " "; // Clear the "Phys Distance" reading if there is no hit 
                rayHitIndicator.SetActive(false); // hide rayHitIndicator if there is no hit
            }
            return false;
        }
    }
}

